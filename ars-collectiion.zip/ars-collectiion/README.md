# ARS COLLECTION WEBSITE

Premium digital tools website with admin panel.

## Features
- Countdown timer for Shunter (unlocks 2026-01-01 08:00)
- WhatsApp order integration
- Admin panel for product management
- Multi-user system (1 owner + 5 admins)
- Auto sold out system

## Installation
1. Clone repository
2. Install dependencies: `npm install`
3. Run development: `npm run dev`
4. Open http://localhost:3000

## Deploy to Vercel
1. Push to GitHub
2. Import to Vercel
3. Deploy automatically

## Admin Access
- Owner: username=`owner`, password=`owner123`
- Admin: username=`admin1`, password=`admin123`