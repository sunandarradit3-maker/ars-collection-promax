'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

// Mock data
const mockProducts = [
  { id: 1, name: 'Tools Shunter', price: 100000000, stock: 10, orders: 5 },
  { id: 2, name: 'AI Prompts', price: 500000, stock: 50, orders: 25 },
  { id: 3, name: 'Ebook Premium', price: 300000, stock: 100, orders: 45 },
];

const mockOrders = [
  { id: 1, product: 'Tools Shunter', customer: 'John Doe', status: 'Pending' },
  { id: 2, product: 'AI Prompts', customer: 'Jane Smith', status: 'Completed' },
];

export default function AdminDashboard() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [products, setProducts] = useState(mockProducts);
  const [orders, setOrders] = useState(mockOrders);

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem('user');
    if (!userData) {
      router.push('/admin/login');
    } else {
      setUser(JSON.parse(userData));
    }
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('user');
    router.push('/admin/login');
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <div className="flex items-center gap-4">
            <span className="text-gray-400">Welcome, {user.username}</span>
            <button
              onClick={handleLogout}
              className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* Dashboard Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-gray-800 p-6 rounded-xl">
            <h3 className="text-lg font-semibold mb-2">Total Products</h3>
            <p className="text-3xl font-bold text-purple-500">{products.length}</p>
          </div>
          <div className="bg-gray-800 p-6 rounded-xl">
            <h3 className="text-lg font-semibold mb-2">Total Orders</h3>
            <p className="text-3xl font-bold text-green-500">{orders.length}</p>
          </div>
          <div className="bg-gray-800 p-6 rounded-xl">
            <h3 className="text-lg font-semibold mb-2">Revenue</h3>
            <p className="text-3xl font-bold text-blue-500">
              Rp {products.reduce((sum, p) => sum + (p.price * p.orders), 0).toLocaleString()}
            </p>
          </div>
        </div>

        {/* Products Table */}
        <div className="bg-gray-800 rounded-xl p-6 mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold">Products Management</h2>
            <button className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded">
              Add Product
            </button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="text-left p-3">ID</th>
                  <th className="text-left p-3">Product Name</th>
                  <th className="text-left p-3">Price</th>
                  <th className="text-left p-3">Stock</th>
                  <th className="text-left p-3">Orders</th>
                  <th className="text-left p-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => (
                  <tr key={product.id} className="border-b border-gray-700/50">
                    <td className="p-3">{product.id}</td>
                    <td className="p-3">{product.name}</td>
                    <td className="p-3">Rp {product.price.toLocaleString()}</td>
                    <td className="p-3">
                      <span className={`px-3 py-1 rounded-full text-sm ${product.stock > 10 ? 'bg-green-900/30 text-green-400' : 'bg-red-900/30 text-red-400'}`}>
                        {product.stock} {product.stock === 0 && '(Sold Out)'}
                      </span>
                    </td>
                    <td className="p-3">{product.orders}</td>
                    <td className="p-3">
                      <div className="flex gap-2">
                        <button className="bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded text-sm">
                          Edit
                        </button>
                        <button className="bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-sm">
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Orders Table */}
        <div className="bg-gray-800 rounded-xl p-6">
          <h2 className="text-xl font-bold mb-6">Recent Orders</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="text-left p-3">Order ID</th>
                  <th className="text-left p-3">Product</th>
                  <th className="text-left p-3">Customer</th>
                  <th className="text-left p-3">Status</th>
                  <th className="text-left p-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id} className="border-b border-gray-700/50">
                    <td className="p-3">#{order.id}</td>
                    <td className="p-3">{order.product}</td>
                    <td className="p-3">{order.customer}</td>
                    <td className="p-3">
                      <span className={`px-3 py-1 rounded-full text-sm ${order.status === 'Completed' ? 'bg-green-900/30 text-green-400' : 'bg-yellow-900/30 text-yellow-400'}`}>
                        {order.status}
                      </span>
                    </td>
                    <td className="p-3">
                      <button className="bg-purple-600 hover:bg-purple-700 px-3 py-1 rounded text-sm">
                        View Details
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}