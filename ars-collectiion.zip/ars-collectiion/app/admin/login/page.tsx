'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminLogin() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple auth (in production, use proper auth)
    const adminUsers = [
      { username: 'owner', password: 'owner123', role: 'owner' },
      { username: 'admin1', password: 'admin123', role: 'admin' },
      { username: 'admin2', password: 'admin456', role: 'admin' },
      { username: 'admin3', password: 'admin789', role: 'admin' },
      { username: 'admin4', password: 'admin000', role: 'admin' },
      { username: 'admin5', password: 'admin111', role: 'admin' },
    ];

    const user = adminUsers.find(
      (u) => u.username === username && u.password === password
    );

    if (user) {
      // Store in localStorage (in production, use proper session)
      localStorage.setItem('user', JSON.stringify(user));
      
      if (user.role === 'owner') {
        router.push('/owner/dashboard');
      } else {
        router.push('/admin/dashboard');
      }
    } else {
      setError('Username atau password salah');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900">
      <div className="bg-gray-800 p-8 rounded-xl w-full max-w-md">
        <h1 className="text-3xl font-bold mb-6 text-center">ARS COLLECTION ADMIN</h1>
        
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-3 bg-gray-700 rounded-lg"
              placeholder="Enter username"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3 bg-gray-700 rounded-lg"
              placeholder="Enter password"
              required
            />
          </div>
          
          {error && (
            <div className="text-red-500 text-sm">{error}</div>
          )}
          
          <button
            type="submit"
            className="w-full bg-purple-600 hover:bg-purple-700 py-3 rounded-lg font-semibold"
          >
            Login
          </button>
        </form>
        
        <div className="mt-6 text-center text-sm text-gray-400">
          <p>Owner & Admin Panel</p>
          <p>Max 6 users (1 Owner + 5 Admin)</p>
        </div>
      </div>
    </div>
  );
}