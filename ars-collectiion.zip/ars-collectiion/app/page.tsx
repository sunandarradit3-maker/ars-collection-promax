import CountdownTimer from '@/components/CountdownTimer';
import ProductGrid from '@/components/ProductGrid';
import WhatsAppButton from '@/components/WhatsAppButton';

export default function Home() {
  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 gradient-text">
            ARS COLLECTION
          </h1>
          <p className="text-xl text-gray-400 mb-10">
            Premium Digital Tools & Resources
          </p>
          
          {/* Countdown untuk Shunter */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold mb-4">TOOLS SHUNTER - Rp 100.000.000</h2>
            <CountdownTimer targetDate="2026-01-01T08:00:00+07:00" />
            <p className="text-gray-500 mt-4">Available: 1 Januari 2026, 08:00 WIB</p>
          </div>

          {/* Product Grid */}
          <ProductGrid />

          {/* WhatsApp Button */}
          <WhatsAppButton 
            phone="+6287739435496"
            message="Halo Ars Collection, saya tertarik dengan produk Anda"
          />
        </div>
      </section>
    </main>
  );
}