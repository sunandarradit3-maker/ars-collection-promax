'use client';

import { useState, useEffect } from 'react';

interface CountdownTimerProps {
  targetDate: string;
}

export default function CountdownTimer({ targetDate }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const target = new Date(targetDate).getTime();
      const now = new Date().getTime();
      const difference = target - now;

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000),
        });
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [targetDate]);

  const TimeBox = ({ value, label }: { value: number; label: string }) => (
    <div className="bg-gray-900 rounded-xl p-4 min-w-[100px] text-center">
      <div className="text-4xl font-bold text-purple-500">{value.toString().padStart(2, '0')}</div>
      <div className="text-sm text-gray-400 mt-2">{label}</div>
    </div>
  );

  return (
    <div className="flex justify-center gap-4 mb-8">
      <TimeBox value={timeLeft.days} label="HARI" />
      <TimeBox value={timeLeft.hours} label="JAM" />
      <TimeBox value={timeLeft.minutes} label="MENIT" />
      <TimeBox value={timeLeft.seconds} label="DETIK" />
    </div>
  );
}