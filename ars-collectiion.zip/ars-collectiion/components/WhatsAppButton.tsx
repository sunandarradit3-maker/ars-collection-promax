'use client';

interface WhatsAppButtonProps {
  phone: string;
  message: string;
}

export default function WhatsAppButton({ phone, message }: WhatsAppButtonProps) {
  const handleClick = () => {
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/${phone}?text=${encodedMessage}`, '_blank');
  };

  return (
    <button
      onClick={handleClick}
      className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg z-50 flex items-center gap-2 transition-all"
    >
      <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12.032 2c-5.5 0-9.977 4.477-9.977 9.977 0 1.768.47 3.492 1.362 5.003L2 22l5.233-1.356a9.937 9.937 0 004.8 1.232c5.5 0 9.977-4.477 9.977-9.977s-4.477-9.977-9.977-9.977zm5.432 14.86c-.25.7-1.404 1.282-1.954 1.35-.5.06-1.126.08-1.67-.088-.5-.16-1.108-.37-1.916-.68-3.29-1.29-5.426-4.5-5.59-4.71-.16-.21-1.29-1.72-1.29-3.28 0-1.56.8-2.33 1.12-2.66.28-.28.74-.36 1.01-.36.25 0 .5 0 .72.01.28.01.6-.1.87.7.35 1.01 1.2 3.49 1.31 3.74.1.25.2.55.1.86-.1.31-.25.5-.5.8-.25.28-.55.61-.79.82-.25.21-.5.43-.22.85.28.43 1.26 1.83 2.7 2.95 1.86 1.45 3.39 1.89 3.84 2.09.45.2.94.17 1.29-.11.35-.28 1.5-1.75 1.91-2.35.41-.6.82-.5 1.12-.5.3 0 .82.1 1.26.5.44.4 1.71 1.68 2 1.98.29.3.59.7.69 1.1.1.4.1 2.19-.15 2.89z"/>
      </svg>
      <span className="font-semibold">Order Now</span>
    </button>
  );
}