'use client';

interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  category: string;
  soldOut: boolean;
  image: string;
}

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  const waMessage = `Halo Ars Collection, saya mau order:\n\nProduk: ${product.name}\nHarga: ${formatPrice(product.price)}\n\nMohon info cara ordernya.`;

  return (
    <div className="bg-gray-900 rounded-xl overflow-hidden border border-gray-800 hover:border-purple-600 transition-all duration-300">
      {/* Sold Out Badge */}
      {product.soldOut && (
        <div className="absolute top-4 right-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-bold">
          SOLD OUT
        </div>
      )}

      {/* Product Image */}
      <div className="h-48 bg-gradient-to-br from-purple-900/50 to-blue-900/50 flex items-center justify-center">
        <div className="text-6xl text-purple-400">
          {product.category === 'Digital Tools' && '🔧'}
          {product.category === 'AI Resources' && '🤖'}
          {product.category === 'Ebooks' && '📚'}
          {product.category === 'Security' && '🛡️'}
          {product.category === 'Apparel' && '👕'}
        </div>
      </div>

      {/* Product Info */}
      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold">{product.name}</h3>
          <span className="text-sm text-gray-400 bg-gray-800 px-2 py-1 rounded">
            {product.category}
          </span>
        </div>
        
        <p className="text-gray-400 mb-4">{product.description}</p>
        
        <div className="flex justify-between items-center">
          <span className="text-2xl font-bold text-purple-500">
            {formatPrice(product.price)}
          </span>
          
          {!product.soldOut ? (
            <a
              href={`https://wa.me/6287739435496?text=${encodeURIComponent(waMessage)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-green-500 hover:bg-green-600 px-6 py-2 rounded-lg font-semibold transition"
            >
              Order WA
            </a>
          ) : (
            <button
              disabled
              className="bg-gray-800 text-gray-500 px-6 py-2 rounded-lg font-semibold cursor-not-allowed"
            >
              Sold Out
            </button>
          )}
        </div>
      </div>
    </div>
  );
}