// ProductCard.tsx placeholder
