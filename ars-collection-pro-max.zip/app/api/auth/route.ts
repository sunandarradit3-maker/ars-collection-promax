// api/auth/route.ts placeholder
