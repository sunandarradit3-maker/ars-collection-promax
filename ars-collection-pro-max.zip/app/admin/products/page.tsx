// admin/products/page.tsx placeholder
