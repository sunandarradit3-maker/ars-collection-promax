// admin/dashboard/page.tsx placeholder
