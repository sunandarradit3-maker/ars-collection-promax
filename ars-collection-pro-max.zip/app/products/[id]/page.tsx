// products/[id]/page.tsx placeholder
