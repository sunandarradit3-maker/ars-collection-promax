// products/page.tsx placeholder
