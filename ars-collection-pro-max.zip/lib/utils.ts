// utils.ts placeholder
