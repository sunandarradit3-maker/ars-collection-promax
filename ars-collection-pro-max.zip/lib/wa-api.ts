// wa-api.ts placeholder
